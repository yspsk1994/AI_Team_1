from abc import ABC, abstractmethod 

class  Mediator ( ABC): 
 
    def  send_message ( self, target, message): 
        pass